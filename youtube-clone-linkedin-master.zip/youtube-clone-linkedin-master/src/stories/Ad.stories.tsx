import { Meta } from '@storybook/react/types-6-0';

import AdBanner from '../components/AdBanner';

export default {
  title: 'LinkedIn/AdBanner',
} as Meta;

export { AdBanner };
