import styled from 'styled-components';

export const Container = styled.div`
  @media (min-width: 1180px) {
    width: 552px;
  }
`;
