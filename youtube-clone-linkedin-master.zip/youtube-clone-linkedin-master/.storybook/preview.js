const { decorators } = require('./decorators');

export const parameters = {
  actions: { argTypesRegex: '^on[A-Z].*' },
};

export { decorators };
